# Presidential Debates, 1960–2024

This corpus holds all 37 general-election presidential debates from Kennedy–Nixon in 1960 to Harris–Trump in 2024. It totals roughly 570,000 words, of which about 483,000 are the candidates’ own (exact totals vary by a percent or two with how words are counted). The format barely changes over 64 years: two candidates (three in 1992), questions from journalists or voters, and fixed time limits. That makes the corpus good for asking how American political talk has changed: attack politics, the agenda, how candidates answer (or dodge) questions, and how they talk about the country.

The same debates come at three levels, so students can choose the unit that fits their question:

| Level | Folder | Files | What one file is |
|---|---|---|---|
| Debates | `texts/debates/` | 37 | A whole debate, every speaker, with uniform labels |
| Candidates | `texts/candidates/` | 77 | Everything one candidate said in one debate |
| Turns, sample | `texts/turns_sample/` | 290 | One answer, with the turn that preceded it (balanced sample) |
| Turns, all | `texts/turns_all/` | 1,874 | The same, for every answer of 50 words or more |

| Election | Debates | Candidates |
|---|---|---|
| 1960 | 4 | Kennedy (D), Nixon (R) |
| 1976 | 3 | Carter (D), Ford (R) |
| 1980 | 2 | Carter (D), Reagan (R), Anderson (I) |
| 1984 | 2 | Mondale (D), Reagan (R) |
| 1988 | 2 | Dukakis (D), G. H. W. Bush (R) |
| 1992 | 3 | B. Clinton (D), G. H. W. Bush (R), Perot (I) |
| 1996 | 2 | B. Clinton (D), Dole (R) |
| 2000 | 3 | Gore (D), G. W. Bush (R) |
| 2004 | 3 | Kerry (D), G. W. Bush (R) |
| 2008 | 3 | Obama (D), McCain (R) |
| 2012 | 3 | Obama (D), Romney (R) |
| 2016 | 3 | H. Clinton (D), Trump (R) |
| 2020 | 2 | Biden (D), Trump (R) |
| 2024 | 2 | Biden (D) in June, Harris (D) in September, Trump (R) |

There were no general-election debates in 1964, 1968, or 1972. The 1980 debates were Reagan–Anderson and Carter–Reagan; Carter and Anderson never met. Vice-presidential debates are not included.

## What’s in the folder

- **`texts/debates/`** has one file per debate, named `PD-` plus the date (for example `PD-1960-09-26.txt`). Each file starts with three header lines (the American Presidency Project’s title; date, place, and candidates; source link), a blank line, and then the transcript. Candidates are labeled with name and party (`KENNEDY (D):`); everyone else by surname as the transcript gives it (`SMITH:`), or as `MODERATOR:`, `AUDIENCE QUESTION:`, or `AUDIENCE:` (a heckle). Audience reactions such as `(Applause)` appear as they do in the source.
- **`texts/candidates/`** has one file per candidate per debate (`PD-1960-09-26_KENNEDY.txt`): everything that candidate said, in order. Turns are separated by `---`. Short interruptions the candidate made while the opponent was speaking (“Wrong,” “That’s not true”) are included in their place and marked `[interjection]`. Other speakers are left out, so read the debate file when you need the question.
- **`texts/turns_sample/`** has 290 single turns: 10 per major-party candidate per election year, drawn at random (fixed seed) from turns of 50 words or more. In 2024 there are 10 each for Biden, Harris, and Trump. Anderson and Perot are not in the sample. Start here: the sample is balanced across years and small enough to check by hand.
- **`texts/turns_all/`** has every turn of 50 words or more, 1,874 files, in the same format (the 290 sample files are copies of files in this folder). Use it when your question needs more than the sample: every answer by one candidate, a run of elections, or a topic you will filter for. File names say debate date, turn number, and candidate (`PD-2016-09-26_T012_TRUMP.txt`), so you can pick a subset by name. This folder is not balanced: busy years have more than twice as many answers as thin ones (76 in 1980, 184 in 2004), so compare proportions, not counts, across years. Running the whole folder costs a little more than annotating all 37 full debates (roughly 590,000 words, because each file also carries its preceding turn).
- **Format of turn files.** Each file has a header, then `PRECEDING TURN (speaker):` with the full turn just before it (usually the question, sometimes the opponent’s answer), then `TURN (candidate):` with the answer itself. **When annotating, tell the model to code only the TURN section and to use the preceding turn as context.**
- **`presidential_debates_metadata.xlsx`**:
  - **Debates:** one row per debate, with date, place, format, moderators and panelists, transcript type, word counts, and the note APP prints beneath the transcript (`app_source_note`: where the text comes from, how it was revised).
  - **Candidate files:** one row per candidate file, with party, status going into the election, whether the candidate’s party held the White House (`incumbent_party`), whether the candidate won, and counts of turns, interjections, and words.
  - **Turns:** all 2,302 candidate turns (not just the sample), with full text, the preceding turn, word count, and whether the turn is in the sample, and its file name. Students who want a different sample can filter this sheet and pick the matching files from `texts/turns_all/`.
  - **Summary:** live counts by year and party.
  - **Verification**, **Verification (reverse)**, and **Column guide.**
- **`verification/`** holds the records of how the corpus was checked: everything the parser removed, split, or fixed (`parse_log.txt`), and the speaker-attribution checks in both directions with every disagreement they found.

## What a “turn” is

A turn is everything a candidate says between the moment the transcript gives them the floor and the moment another speaker takes it. Two adjustments make that closer to what we would call an answer:

- **Short interruptions are absorbed.** When a candidate’s answer is broken by an interjection of under 15 words (“That’s not true,” “Let him finish”) and the same candidate then carries on, the pieces are joined into one turn. In the turn, the interjection is replaced by `[interjection by NAME]`, so the turn contains only the answering candidate’s words. The interjection’s words are kept in the Turns sheet (column `interjection_text` of the turn it interrupted; `interjections_absorbed` counts the interruptions of that turn, and an interruption that was itself interrupted counts once), in the full debate file, and, if a candidate made it, in that candidate’s own file. Interjections are therefore **not** separate rows in the Turns sheet: to study interruptions, use the candidate files or the `interjection_text` column.
- **Use turns of 50 words or more** for most purposes. Shorter turns are mostly quips and protests. There are 1,874 turns of 50 words or more; their median length is about 240 words.

Even with merging, how many turns a debate has partly reflects how chaotic it was. The first 2020 debate still has 199 candidate turns, against 20 to 28 in each 1960 debate. Counts of turns are therefore a finding in their own right, not just a sampling unit.

## How the corpus was built

1. **Source.** All 37 debates were downloaded from the American Presidency Project (APP), which hosts a transcript of every general-election debate since 1960. The list was checked against the expected number of debates per cycle.
2. **Splitting by speaker.** The transcripts use several labeling styles across the decades (`MR. NIXON:`, `THE PRESIDENT.`, `The President.`, `TRUMP:`). Each style was parsed explicitly, and every label was mapped to a candidate or kept as a non-candidate. Where the source runs a new speaker into the same paragraph or line (for example “...Thank you. BROKAW: Senator McCain, you get the last word”), the text was split at the label. Every such split is listed in the log.
3. **Fixed:** label typos in the source: a semicolon or comma instead of a colon or period (“MR. NIXON;” and “MR, KENNEDY:” in 1960; “Mr, Mondale,” and two other 1984 labels), a doubled period (“THE MODERATOR..”), a missing space (“TRUMP:. . .” in 2020), a label followed directly by a dash (“Gov. Romney.——” in 2012), misspellings (“SM1TH,” “THE. PRESIDENT,” “MR. CATER” for Carter in 1976), and garbled characters in two *Public Papers* transcripts (“Â”). Also fixed: labels the source writes out in full only once (“Republican Presidential Nominee W. Mitt Romney”) and one label that stood in a paragraph of its own (Hartford 1996). All are in the log.
4. **Removed:** the corpus uses only the transcript part of each APP page. From that, the following were removed: the APP citation line, header lines listing participants, editors’ notes and footnotes from the *Public Papers of the Presidents*, and the topic headings the *Public Papers* editors inserted (“Health Care Reform,” “Closing Statements”). All of these are listed in `verification/parse_log.txt`. APP’s own note beneath each transcript is not part of the text files; it is in the `app_source_note` column.
5. **Candidate files and turns** were built from the speaker-split text as described above.

## How it was checked

- **Completeness.** Every word in each APP transcript was accounted for: it is either in the debate file or among the logged removals and label fixes.
- **Speaker attribution, two ways.** The Commission on Presidential Debates (CPD) publishes its own transcripts of every debate from 1960 to 2020, so each debate can be checked against an independent source.
  - *Corpus to CPD:* each candidate sentence of eight words or more in this corpus was looked up in the CPD transcript. Of 17,183 sentences found in both, 98.8 percent are credited to the same candidate.
  - *CPD to corpus:* every passage CPD credits to a candidate was cut into 12-word windows and looked up in this corpus. Of 32,712 windows found, 99.9 percent are credited to the same candidate. This direction matters: the first check cannot see candidate speech that the corpus wrongly gives to a moderator.
  - The remaining disagreements (198 and 43) were traced by hand to the CPD side or to the checking script: CPD transcripts sometimes run two speakers together on one line, omit a label, misspell one (“REAGAV,” “ROMNEHY”), or give a journalist’s question to a candidate. Of the first kind, 56 come from four 1960 answers by Nixon and Kennedy that CPD, sharing the source’s label typos, credits to the journalists.
  - **A limit of these checks:** they cannot catch an error that APP and CPD share. The 1960 typos were found by reading, not by the comparison. In one place (Boca Raton, October 22, 2012) CPD prints the label ROMNEY twice in a row, so it gives Romney a line, “And then you cut education spending when you came into office,” that APP gives to Obama. The doubled label is almost certainly a CPD typo, and the context supports APP. Two short moderator lines are genuinely ambiguous, and the corpus follows APP: “Just very briefly” (East Lansing 1992; CPD gives it to Clinton) and “Trying to figure out who the questioner was” (Winston-Salem 2000; CPD gives it to Bush, which fits the context at least as well).
- **2024.** The 2024 debates were not organized by the CPD, so there is no second transcript to check against. Both were read in full to check every speaker label (see below); none was wrong.
- **Independent audits.** Two separate AI agents that had not built the corpus audited it in turn. The first checked 50 randomly chosen turns against the APP source (all correctly attributed and complete, with the right preceding turn), read both 2024 debates in full, compared 10 candidate files and all 37 debate files with the source, and checked the metadata and this README. It found five places where the parser had missed a speaker label run into the middle of a paragraph (about 1,000 words of candidate speech attributed to journalists in 1984, 1988, and 2008), several smaller run-together labels, four editorial notes left in, and inaccuracies in an earlier version of this README. All were fixed, and the fixes were confirmed with the reverse attribution check above and by checking each reported passage. That check also found and fixed Romney’s first answer in each 2012 debate, which had been given to the moderator. The second audit then checked the whole corpus exhaustively: a scan of every paragraph for hidden speaker changes, an alignment of every labeled passage in the APP source with the corpus, its own comparison with CPD in both directions, a rebuild of all turns, candidate files, and turn files from the debate files, and every metadata row. It found six remaining label errors, all caused by typos in the source: four 1960 answers by Nixon and Kennedy (about 1,560 words) attributed to journalists, plus short lines in 1976, 1980, 1992, 2012, and 2020. These were fixed, and the auditor’s own scripts were rerun on the corrected corpus: they find no hidden labels, every turn file matches its debate file, and every metadata row is consistent.

## Things students should know

- **Moderators set the agenda.** Questions decide most of the topics. If you count topics in the candidates’ answers, you are partly counting the moderators’ choices. Code the question and the answer separately (the turn files make this easy), and look for what candidates raise unprompted or pivot to.
- **Formats differ.** Debates before 1992 were mostly panels of journalists; from 1992 there are single-moderator debates and town halls where voters ask the questions. The `format` column records this. Format affects length of turns, tone, and topics, so compare like with like or control for it.
- **Two kinds of transcript.** For 17 debates, APP prints the version in the official *Public Papers of the Presidents*, which is lightly edited: fillers such as “uh” are removed and some wording is smoothed. The other 20 are verbatim transcripts from broadcasters or the CPD. The `transcript_type` column says which. Do not study disfluency, hesitation, or exact wording across this divide. Even the verbatim transcripts differ: fillers are written down in all four 1960 debates and only occasionally afterward (most in the September 2024 ABC transcript).
- **Transcribers marked reactions differently.** “(Crosstalk),” “[Laughter],” and “(Applause)” appear far more in some years than others because of transcription habits, not only because of what happened. Don’t count them.
- **Status and incumbency.** The `status` column describes each candidate’s position going into the election: incumbent president, sitting vice president, former president, challenger (the out-party nominee facing a sitting president or vice president), independent challenger, or open seat. “Open seat” is used only for 2008 and 2016, when neither the president nor the vice president ran. For a simple in-party/out-party comparison, use `incumbent_party` instead, which is yes for the nominee of the party holding the White House (so Nixon 1960, McCain 2008, Hillary Clinton 2016, and Harris 2024 are yes).
- **Uneven cycles.** 1980 is thin (two debates, one of them without the incumbent). 1992 has a third candidate. 2024 has two different Democrats: Biden in June, Harris in September. Biden withdrew from the race and is coded as not winning.
- **The turn sample is small per cell.** Ten turns per candidate per year is enough for describing patterns, not for testing fine differences between single years. Group years into eras, or use more answers from `texts/turns_all/`.
- **Preparation.** Debate answers are rehearsed and often drafted by advisers, but they are delivered live and unscripted in a way stump speeches are not.
- **Language.** The debates include heated and sometimes insulting exchanges, and discussion of violence, race, and immigration in the terms of their time.

## Possible research questions

- **Attack politics.** How often do candidates attack the opponent, and is the attack about policy or character? When did the shift happen, and do challengers attack more than incumbents?
- **Interruptions.** Who interrupts whom, how often, and with what? (Use the `[interjection]` lines in the candidate files.)
- **Answering the question.** How often do candidates answer what was asked, and what do they pivot to?
- **The agenda.** Which issues do candidates raise unprompted, and how does that change from the Cold War to the war on terror to the 2020s?
- **National self-image.** Optimism, decline, and “greatness”: how do candidates describe the state of the country?
- **The people.** Who appears in the answers: ordinary Americans by name, “working families,” elites, enemies?
- **Gender.** How do Hillary Clinton (2016) and Kamala Harris (2024) talk, and how are they talked about, compared with the men they debated?
- **Format effects.** Are candidates different in town halls than in moderator-led debates?

A good design is to hand-code a sample of 30 turns first and compare your codes with the model’s before running it on the full sample.

## Source, rights, and citation

The transcripts are from Gerhard Peters and John T. Woolley, *The American Presidency Project*, presidency.ucsb.edu; each row in the metadata links to its page. The *Public Papers* versions are U.S. government documents. The other transcripts are broadcast transcripts that APP republishes (and in some cases has revised) as a scholarly archive, so the corpus as a whole should not be treated as public domain. Classroom research use is standard, but cite APP and don’t republish the texts in bulk.

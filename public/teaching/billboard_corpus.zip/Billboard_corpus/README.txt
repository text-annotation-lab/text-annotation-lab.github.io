﻿BILLBOARD LYRICS CORPUS — REVISED PACKAGE

CONTENTS
texts/: one plain-text file per retained artist-title-year record, organized
by chart year. These contain the supplied lyrics only; metadata are in the
filename and manifest.csv.
manifest.csv: record IDs, filenames, song titles, artists, and chart years.
Billboard_with_lyrics_updated.xlsx: the complete revised workbook, with Songs,
English documentation in the existing "Om data" tab, and an Excluded entries
tab documenting the 31 most recent removals.
Billboard_with_lyrics_updated.csv: the same 4,547 retained records in CSV format.
excluded_entries_all_stages.csv: all 1,154 excluded source records, with stage
and reason. Source row is the 1-based data-row position in the original R
lyrics dataset, excluding its column header; it is not an Excel row number.
CHECKSUMS.txt: SHA-256 hashes for all other files in this package.

SOURCE
Mikkel Freltoft Krogsholm, billboard R package, version 0.1.0, lyrics dataset.
https://cran.r-project.org/web/packages/billboard/index.html
https://cran.r-project.org/src/contrib/billboard_0.1.0.tar.gz
The package documents Genius as the source of its scraped lyrics and warns
that retrieval errors may be present. Its stated package license is MIT +
LICENSE; that label is not a separate clearance of underlying song copyrights.

COVERAGE AND UNIT OF ANALYSIS
Billboard Year-End Hot 100 entries, 1960–2016. There are 4,547 retained
artist–title–year records, not necessarily 4,547 distinct songs. Songs appearing
in multiple years remain separate records. The year is the year-end chart
year, not necessarily the year of release. This represents charting hits, not
all songs released or all American music.

COLUMNS
  title: song title as supplied by the source
  artist: credited artist as supplied by the source
  year: year on the year-end chart
  lyrics: complete supplied text, preserved verbatim for retained records
"Complete supplied text" does not certify that a transcription is complete.

FILTERING HISTORY
Original dataset: 5,701 records.
Initial removals: 1,094 missing/empty texts and 29 instrumental-only markers
or descriptions. This left 4,578 records.
Subsequent review: 31 additional records removed — 20 instrumental/wordless
recordings with inappropriate verbal texts, 10 wrong lyric matches, and one
incomplete transcription (Dear One, Larry Finnegan).
Forever by The Little Dippers (1960) was reviewed and retained: its short
lyric is genuine rather than an instrumental placeholder.
Final dataset: 4,547 records. Total removed: 1,154.
No further exclusions or repairs were made. Retained wording, metadata,
source order, repetitions and structural markers remain unchanged.

KNOWN LIMITATIONS
This is targeted filtering, not exhaustive validation against recordings.
Other wrong song matches, incomplete transcriptions, version mismatches,
joined words and other formatting defects may remain. Non-English and
multilingual texts have not been systematically screened. Missing coverage
varies over time; historical comparisons require attention to this pattern.

OPENING AND USING THE FILES
For Text Annotation Lab, unzip the package and upload selected TXT files
from texts/ in the Workspace tab. Start with a small pilot. Upload only the
song files, not the README, manifest, exclusion log, or spreadsheets.
The TXT, CSV, and Excel versions contain the SAME records. Use one format
for a study; do not combine the versions as independent observations.
For Excel, open the XLSX directly. Each song text is in one lyrics cell.
Expand the formula bar or enter the cell to inspect the full stored text.
For CSV, use Excel's Data > From Text/CSV, UTF-8 encoding, comma delimiter
and double-quote text qualifier. Embedded lyric line breaks are intentional;
a CSV-aware parser must keep them inside the quoted lyrics field.
The CSV and the Songs sheet contain the SAME records. Use one or the other,
not both combined. The other workbook tabs are documentation, not input texts.

REFERENCES USED FOR THE TARGETED REVIEW
https://www.goldminemag.com/music-history/top-instrumental-songs-from-1950s-and-1960s/
https://www.frankmills.com/bio/
https://marvinhamlisch.com/about/
https://www.musicvf.com/song.php?id=47914
https://www.musicnotes.com/sheetmusic/the-little-dippers/forever/MN0313927
Wrong lyric matches were also compared directly with matching texts assigned
to other titles in the original corpus. Exclusions are documented in the log.

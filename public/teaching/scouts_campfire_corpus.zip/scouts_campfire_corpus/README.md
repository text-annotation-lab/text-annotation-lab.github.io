# Boy Scouts and Camp Fire Girls: Series Fiction, 1912–1919

This corpus has 120 chapters: five chapters from each of 24 novels for young readers. Twelve novels are about Camp Fire Girls and twelve are about Boy Scouts. All were published between 1912 and 1919, just after both organizations were founded (the Boy Scouts of America in 1910, the Camp Fire Girls in 1910–12). The books tell the same basic kind of story: a group of young people go camping, hiking, or traveling, earn badges or honors, and have adventures. The difference is that one group is girls and the other is boys. This makes it a good corpus for comparing how popular fiction imagined girlhood and boyhood at the time.

| | Camp Fire Girls | Boy Scouts |
|---|---|---|
| Books | 12 | 12 |
| Chapters | 60 | 60 |
| Words | ~159,000 | ~137,000 |
| Mean words per chapter | ~2,650 | ~2,280 |

## What's in the folder

- `texts/girls/` and `texts/boys/` hold one `.txt` file per chapter. Each file starts with three header lines (book title; author, publisher, and year; chapter number and title), a blank line, and then the chapter text.
  - File names encode the design. For example, `G-18606-ch03.txt` is a **G**irls' book, Project Gutenberg number 18606, chapter 3.
  - If you want the chapter text without the header (for example, for word counts), drop the first four lines.
- `scouts_campfire_metadata.xlsx` has three sheets:
  - **Metadata:** one row per chapter, with side, publisher, author, title, series, year, chapter number, position (first/middle/last), chapter title, word count, and a source link.
  - **Summary:** live counts and word totals by publisher and side.
  - **Column guide.**

## How the corpus was built

**Matched by publisher.** Three publishers of cheap series fiction, A. L. Burt, Saalfield, and M. A. Donohue, each sold both a Camp Fire Girls series and a Boy Scouts series. From each publisher the corpus takes three girls' books and three boys' books. This holds the price point, the intended market, and much of the house style constant, so that sex is the main thing that varies. The two A. L. Burt series even share a setting: *The Camp Fire Girls in the Maine Woods* and *The Boy Scouts in the Maine Woods*.

The remaining six books (three per side) come from six other publishers. These include more "respectable" houses such as Houghton Mifflin and Revell, which add some range. Isabel Hornibrook wrote one book on each side (*A Scout of To-day*, *Girls of the Morning-Glory Camp Fire*), so those two form a same-author pair.

| Publisher | Camp Fire Girls | Boy Scouts |
|---|---|---|
| A. L. Burt | Hildegard G. Frey: *Maine Woods*, *Go Motoring*, *At School* | Herbert Carter: *Maine Woods*, *First Camp Fire*, *Big Timber* |
| Saalfield | Jane L. Stewart: *Long Lake*, *On the Farm*, *In the Mountains* | Robert Maitland: *Pathfinders*, *Fire Fighters*, *Automobilists* |
| M. A. Donohue | Stella M. Francis: *Twin Lakes*, *Allegheny Mountains*; Irene Elliott Benson: *How Ethel Hollister Became a Campfire Girl* | A. L. Fletcher: *Long Hike*; Alan Douglas: *Tenderfoot Squad*, *Afloat* |
| Other | Vandercook, *Sunrise Hill* (Winston); Thurston, *The Torch Bearer* (Revell); Hornibrook, *Morning-Glory Camp Fire* (Lothrop) | Shaler, *Prize Pennant* (Hurst); Burgess, *Trapper's Camp* (Penn); Hornibrook, *A Scout of To-day* (Houghton Mifflin) |

**Five chapters per book.** Each book contributes its first chapter (which sets up the characters and the premise), its last chapter (which resolves the plot and often states the moral), and three middle chapters chosen at random with a fixed seed. Taking the same positions from every book keeps the sample balanced. It also lets students compare openings with openings and endings with endings.

**War titles were left out on purpose.** From 1915 on, many Scout series moved to the First World War (for example, *The Boy Scouts in Front of Warsaw*). Those books were excluded so that the corpus is about everyday gender roles, not war. George Durston's *The Boy Scouts on the Trail* was dropped after its chapters turned out to be set in wartime France. One military theme remains: in Maitland's *The Boy Scout Automobilists*, the Scouts help a state militia in a war game. That was a normal part of boys' Scouting culture at the time, so it is left in.

**Cleaning.** The Project Gutenberg license header and footer, transcriber's notes, illustration captions, footnotes, and publishers' advertisements at the ends of books were removed. Line breaks within paragraphs were joined. Nothing else was changed. `_Underscores_` mark italics in the original.

## What students should know

- **Author names are not reliable evidence of the author's sex.** Several bylines are publisher house names, and the real writers are often unknown. Likely examples are "Jane L. Stewart" and "Robert Maitland" at Saalfield, and "Captain Alan Douglas, Scout Master" at Donohue. At least two real women wrote Scout books: Isabel Hornibrook and I. T. Thurston (Ida Treadwell Thurston). Do not use the byline to argue that "men wrote the boys' books."
- **Sequels.** Most books belong to a series. First chapters may summarize earlier volumes, and last chapters often advertise the next one.
- **Chapter lengths vary.** Stella M. Francis's Donohue chapters average about 1,000 words, while Frey's and Hornibrook's average 3,300–3,900 words and run up to 5,500. Normalize by length, for example "per 1,000 words," before comparing counts.
- **Years.** Four books have no date in the digital edition. For those, the year comes from catalog records, and the `notes` column says so. *The Boy Scout Automobilists* is dated 1918 in its edition, though the series began in 1912.
- **Offensive and stereotyped content.** The texts use the language and assumptions of their time. Both organizations borrowed heavily from invented "Indian" lore: Camp Fire Girls take "Indian" names such as Sahwah and Nyoda, and "Indian" appears in about a quarter of the chapters. The villains include a kidnapping "gypsy" (in Stewart's Saalfield books), and there are ethnic dialect jokes. These are good material for analysis, but students should be warned before they read.

## Possible research questions and concrete codes

These are easy to code by hand or with an LLM, and they suit a first paper:

- **Who solves the chapter's main problem?** A girl or boy from the group, an adult man, an adult woman, or someone of the other sex.
- **Is there physical danger** (fire, water, animals, getting lost, a villain)? Does the protagonist face it alone?
- **Rescue:** who rescues whom?
- **Emotion:** does anyone cry, blush, or faint? Of which sex?
- **Domestic work:** cooking, sewing, cleaning, or caring for children. Is it framed as a chore, a skill, or an honor?
- **Money and work:** earning, jobs, business, the future career.
- **Explicit statements** about what girls or boys should be ("a Scout is...", "a true Camp Fire girl...").
- **What the outdoors is for:** testing toughness, or health, beauty, and friendship?
- **Conflict type:** an external villain, or a rivalry, jealousy, or quarrel within the group?
- **The other sex:** how are Scouts shown in the girls' books, and girls in the boys' books? Several books have both groups meet.

A good design is to code the 24 first chapters and the 24 last chapters by hand, then check the LLM's codes against yours before running it on all 120 chapters.

## Source and citation

All texts are from **Project Gutenberg** (gutenberg.org). The books are in the public domain in the United States, since they were published before 1929. The `gutenberg_url` column links each chapter to its source edition. The texts were transcribed by Project Gutenberg and Distributed Proofreaders volunteers.

A companion primary source for the boys' side is the *Boy Scouts of America* handbook (1911), Project Gutenberg #29558. The Camp Fire Girls' equivalent, *The Book of the Camp Fire Girls* (1913), is not on Project Gutenberg. HathiTrust and Internet Archive have scans of it.

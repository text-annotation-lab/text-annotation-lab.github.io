# Campaign Speeches: Obama 2008 and Trump 2016

This corpus has 117 speeches from the general-election campaigns of two candidates who each won the presidency as a challenger to the party in power. All speeches were given between August 1 and Election Day.

| Folder | Speaker | Text type | Speeches | Mean words |
|---|---|---|---|---|
| `texts/obama_2008/` | Barack Obama, 2008 | As prepared (campaign text release) | 55 | ~2,850 |
| `texts/trump_2016_prepared/` | Donald J. Trump, 2016 | As prepared for delivery | 41 | ~2,150 |
| `texts/trump_2016_delivered/` | Donald J. Trump, 2016 | Transcript as delivered | 21 | ~4,900 |

## The most important thing to know: prepared vs. delivered

The American Presidency Project (APP) holds two kinds of text:

- **Prepared text:** the speech as the campaign wrote it, usually released to the press.
- **Transcript:** what the speaker actually said, with audience reactions such as `[applause]`.

For 2016, APP has both kinds for Trump and labels them. For Obama's 2008 campaign it has only prepared-style texts. These carry no label, but they contain no audience reactions and repeat the same stump text word for word.

So the fair comparison is **Obama's prepared text against Trump's prepared text**. The Trump transcripts are a separate, extra resource. They show how far a candidate departs from the script on stage. For Trump this was a long way: the transcripts are more than twice as long, with shorter sentences and many more superlatives. Students should never compare Obama's scripts with Trump's transcripts as if they were the same kind of text.

## What's in the folder

- `texts/`: one `.txt` file per speech. Each starts with three header lines (title; speaker and date; text type) and a blank line.
  - IDs: `O-01`… are Obama; `TP-01`… are Trump's prepared texts; `TD-01`… are Trump's delivered texts.
  - Speeches are numbered by date within each group.
- `campaign_speeches_metadata.xlsx`:
  - **Metadata:** one row per speech, with speaker, text type, date, title, occasion, word count, APP's note on the text type, and a link to the source page.
  - **Summary:** live counts by group.

## How the corpus was built

1. **Collection.** All documents that APP tags as "Campaign Remarks & Rallies" for each candidate were collected, from August 1 to Election Day (2008 and 2016).
2. **Exclusions.**
   - Interviews, debates, forums, radio addresses, and excerpts.
   - The nomination acceptance and victory speeches.
   - Anything under 900 words.
3. **Individual corrections.**
   - **O-47 removed.** APP files a Charleston, West Virginia speech (October 24, 2008) under Obama, but the text is clearly Joe Biden's ("give Barack Obama and me the honor…"). The number O-47 is therefore skipped.
   - **One Obama transcript dropped.** Columbia, Missouri (October 30, 2008) is a delivered transcript, so it was left out to keep the Obama set uniform.
   - **TD-06** includes a passage spoken by Nigel Farage, who appeared with Trump.
   - **TD-07** is labeled "as delivered" by APP, but it reads like a prepared text.
4. **Occasion.** The `occasion` column separates rallies and town halls (most speeches) from addresses to organizations and policy speeches, such as the Detroit Economic Club, the VFW, or the Urban League. The split is based on the titles and is rough.

## Things students should know

- **Stump speeches repeat.** Candidates give nearly the same speech many times; several Obama speeches from October share most of their text. Treat the corpus as many performances of a few core texts, not 117 independent statements. Do not use statistical tests that assume each speech is independent.
- **Speechwriters.** Prepared texts are team products, so "Obama's style" or "Trump's style" in them partly reflects the speechwriters. The delivered transcripts are closer to the individual.
- **Different contexts.** 2008 took place during a financial crash, and 2016 did not. Both candidates ran against the party in the White House.
- **Transcription conventions.** Sentence breaks in the transcripts were chosen by the transcriber, which affects measures like sentence length.
- **Copyright and use.** These are campaign speeches, not official presidential documents, so they are not automatically in the public domain. APP publishes them as a scholarly archive. Classroom research use is standard, but cite APP, and don't republish the texts in bulk. Suggested citation: Gerhard Peters and John T. Woolley, *The American Presidency Project*, presidency.ucsb.edu. The metadata links each speech to its APP page.

## Possible research questions

- Populism: how do the two campaigns talk about elites and "the system"? Both do it, but whom do they name?
- Decline narratives: does "the country is in crisis" mean the same thing in 2008 and 2016?
- Attacks: policy criticism vs. attacks on the opponent's character.
- Immigration, terrorism, and trade: which threats appear, and how are they framed?
- Religion, history, and the language of national identity.
- Script vs. performance: what does Trump add, drop, or change when he speaks off the script?
- Change within each campaign from August to November.

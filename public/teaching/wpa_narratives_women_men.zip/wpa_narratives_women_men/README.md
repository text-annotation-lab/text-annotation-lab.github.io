# WPA Slave Narratives: 50 Women and 50 Men, 1936–38

This corpus has 100 interviews with formerly enslaved people, recorded by the Federal Writers' Project of the Works Progress Administration (WPA) in 1936–38. It has 50 women and 50 men, matched by state: each state contributes the same number of women and men. The interviews come from 11 states: Alabama, Florida, Georgia, Maryland, Mississippi, Missouri, North Carolina, Oklahoma, South Carolina, Tennessee, and Texas. In total they run to about 133,000 words, with a median of roughly 1,100 words per interview.

These are the largest body of first-person testimony about American slavery. They are also among the most debated sources in American history, and that debate is part of what makes them a good corpus for students.

## What's in the folder

- **`texts/women/` and `texts/men/`**: one `.txt` file per interview (`W-01`–`W-50`, `M-01`–`M-50`). Each file starts with two header lines: the narrator's name, then the state and source volume. The interview text follows as it appears in the source, including interviewers' headers, notes, and transcriber's notes (`[TR: …]`, `[HW: …]`).
- **`wpa_narratives_metadata.xlsx`**: one row per interview, with narrator, sex, state, source volume, word count, and a link to the source. The Summary sheet has live counts by state.
- **`excluded/`**: four interviews that were drawn and then replaced (see below).

## How the corpus was built

1. **Source.** The Library of Congress collection *Slave Narratives: A Folk History of Slavery in the United States from Interviews with Former Slaves* (1941), as transcribed on Project Gutenberg. It is public domain.
2. **Splitting.** The state volumes were split into individual interviews using each volume's list of informants.
3. **Eligibility.**
   - Only interviews of 500–3,500 words were kept.
   - Composite files that mixed several interviews were left out.
   - Sex was assigned from the narrator's first name. It was then checked against the text of every interview, and all 100 matched.
4. **Sampling.** Interviews were drawn at random, with a fixed seed, to fill a quota per state and sex: for example, 6 women and 6 men from Georgia.
5. **Corrections.**
   - **Replacements:** four drawn narrators turned out never to have been enslaved or to have been born in 1865. They were replaced by reserve draws from the same state and sex. The originals are in `excluded/`, and the metadata column `replaced` records each swap.
   - **Trimming:** four files contained a second, different person's interview appended to the first, and several ended with a stray header from the next interview. These were trimmed by hand.

**Arkansas, the largest state collection, is not included.** Its layout could not be split reliably by the automated method. Neither are Virginia, Kentucky, and Kansas, where the collections are small.

## Things students should know

- **Who asked, and who answered.**
  - Most interviewers were white Southerners, interviewing elderly Black people in the Jim Crow South, often about the families of former owners who still lived nearby.
  - Several narrators hoped the interview would help them get an old-age pension.
  - What people said, or held back, was shaped by all of this. Historians (John Blassingame, Paul Escott, and others) have shown that narrators spoke more critically to Black interviewers. Some Florida and Georgia interviews were done by Black fieldworkers; the Florida ones are marked "Negro Writers' Unit."
- **Dialect.** The dialect spellings ("dey," "massa," "gwine") were written down by the interviewers. They were applied unevenly, and they are themselves evidence of racial attitudes. Quote them carefully and discuss them.
- **Children in 1865.** Most narrators were children or teenagers when slavery ended; the median age at emancipation is about 13. Their memories are a child's memories, recalled some 70 years later.
- **Interviewer's voice.** Some interviews are mostly the interviewer's paraphrase, not the narrator's words. The annotation codes this as `voice`.
- **Content warning.** The texts contain racial slurs, graphic violence (whipping and torture), sexual exploitation, and family separation. They also contain nostalgic descriptions of slavery that must be read in the context above.

## Possible research questions

- **Gender:** Did enslaved women and men remember different slaveries: work, punishment, family, sexual exploitation? (Deborah Gray White, *Ar'n't I a Woman?*; Stephanie Camp, *Closer to Freedom*.)
- **Kind masters:** How should we read the "kind master" memories, and do they vary with who was interviewing?
- **Freedom:** How is freedom remembered: as the arrival of the Yankees, as an announcement, or as a disappointment?
- **Aftermath:** What happened after emancipation, from sharecropping to the Klan?
- **Age:** How does the narrator's age in 1865 shape what they remember?
- **Religion:** What role did religion play under slavery and in how narrators tell their lives?

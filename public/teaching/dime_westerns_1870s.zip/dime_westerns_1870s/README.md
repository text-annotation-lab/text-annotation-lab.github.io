# Dime-Novel Westerns, 1870–1875: 24 Beadle Novels

This corpus contains 24 complete dime novels set in the American West, all published by Beadle and Adams of New York with copyright dates between 1870 and 1875. Together they run to about 754,000 words, roughly 31,000 words per novel.

Beadle and Adams invented the dime novel in 1860 and dominated the market through the 1870s. Their books sold for ten cents (the Pocket Novels also went by subscription, 26 numbers a year) and were read by boys, soldiers, workers, and anyone else with a dime. For most Americans east of the Mississippi, these were among the most common stories they read about the West and about Native Americans.

## What's in the folder

- **`texts/`** holds one `.txt` file per novel, named `DN-` plus the Project Gutenberg number (for example `DN-68102.txt`). Each file starts with two header lines, the title and then the author, series and copyright year, followed by the full novel from Chapter I to the end. Publishers' advertisements and transcriber's notes have been removed. `_Underscores_` mark italics in the original.
- **`dime_westerns_metadata.xlsx`**:
  - **Novels:** one row per novel, with title, real author, the name printed on the title page, series and number, copyright year, setting, Native nations depicted, a one-sentence summary, and a link to the source.
  - **Summary:** counts by year.

## How the corpus was built

1. **Candidates.** Project Gutenberg lists 282 items under "Dime novels." Most of the Beadle frontier novels among them were transcribed from library collections at Villanova and Northern Illinois University.
2. **Selection.** From these, I kept every Beadle and Adams novel that meets all three of these conditions:
   - it has a copyright date in the 1870s;
   - it is set west of the Mississippi (the Plains, Rockies, Southwest, Texas, Oregon or California, plus Minnesota for the 1862 Dakota War);
   - Native characters play a real part in the story.

   That left 24 novels. I excluded Beadle novels set on the colonial, Revolutionary-era or Ohio Valley frontiers, and a few Western titles with almost no Native characters.
3. **Checks.** Every file was checked against the Gutenberg original after cleaning.

**Series:**

| Series | Novels |
|---|---|
| Beadle's Pocket Novels | 19 |
| Beadle's Dime Novels | 3 |
| Beadle's New Dime Novels | 1 |
| Beadle and Adams, series not stated on the title page | 1 |

**Years:** 1870 (3), 1871 (3), 1872 (7), 1873 (6), 1874 (4), 1875 (1).

## Things students should know

- **Authors used pseudonyms.** Beadle writers published under several names, often military-sounding ones. Edward S. Ellis wrote 6 of these novels as "Seelin Robins," "Chas. E. Lasalle," "Lieut. Ned Hunter" and "Capt. J. F. C. Adams." *Nat, the Trapper* was written by a woman, Lettie Artley Irons, under the name "Paul J. Prescott." The metadata gives both the real author (from library catalogs) and the name on the title page.
- **Ellis is overrepresented.** He wrote 6 of the 24 novels. When comparing authors or counting patterns, check that one writer isn't driving the result.
- **One sequel pair.** Willett's *The Gray Scalp* and *Silverspur* share characters. Dove-eye appears in both: she is an "Arapaho girl" in the first book and is revealed as a white captive in the second. That makes the pair a good case for how these novels handle racial identity.
- **Fiction that tracked the news.** *The Squaw Spy* (copyright 1873) is set in the Modoc War of 1872–73, which was still under way or had just ended. *Dusky Dick* fictionalizes the Dakota War of 1862 in Minnesota.
- **Nation names are unreliable.** The novels routinely confuse nations: one has "Modoc Sioux," and another has a Comanche leading Apaches in Arizona. Treat these names as the authors' inventions, not ethnography.
- **Content warning.** The novels are full of racist language ("red devils," "varmints," "squaw," "greaser," and anti-Black slurs), torture scenes, and "Ugh!" caricature of Native speech. That is the point of studying them, but students need warning and framing.

## Possible research questions

- **Names and voices.** Who gets a name and a voice? How do Native characters speak compared with white frontiersmen, who also speak in heavy dialect?
- **The "noble" and the "savage" Indian.** Can you find both types, sometimes in the same novel?
- **Native women.** They are rare. What roles do they play (the "Indian maiden," the helper, the love interest)?
- **White Indians.** What should we make of white characters who pass as Indians: renegades, captives raised by tribes, heroes in disguise? When is crossing the line heroic and when is it villainy?
- **History in the novels.** How is real conflict (the Modoc War, the Dakota War) turned into entertainment?
- **Comparison.** How do these novels compare with Cooper's *Last of the Mohicans* (1826) or Helen Hunt Jackson's *Ramona* (1884)?

## Source and citation

The texts come from Project Gutenberg. They are public domain in the United States, published before 1929. The `gutenberg_url` column links to each source edition, and the transcriptions credit the Digital Library@Villanova University and the Northern Illinois University Digital Library for the page images.

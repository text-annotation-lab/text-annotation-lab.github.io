# Paired Obituaries Corpus: Men and Women in American Local Newspapers, 1880–1959

200 newspaper obituaries in 100 matched pairs. Each pair has one woman's obituary and one man's obituary from the same newspaper, published as close together in time as the sources allowed. The pairs are spread evenly across four periods, 25 pairs each:

| Period | Years sampled | Pairs | Same-issue pairs | Newspapers |
|---|---|---|---|---|
| 1880s | 1880–1889 | 25 | 6 | 25 |
| 1900s | 1903–1909 | 25 | 14 | 25 |
| 1920s | 1920–1922 | 25 | 19 | 25 |
| 1950s | 1955–1959 | 25 | 16 | 17 |

The corpus covers 83 newspapers in 31 states and D.C.: 84 texts are from the Midwest, 68 from the South, 36 from the Northeast, and 12 from the West. The 1950s sample includes two African American newspapers, the *St. Paul Recorder* and the *Minneapolis Spokesman*. They are flagged in the `black_press` column.

## What's in the folder

- `texts_clean/` holds one `.txt` file per obituary, with light, rule-based OCR cleanup (see below). **These are the files to annotate.**
- `texts_raw_ocr/` holds the same texts exactly as they come from the OCR, uncorrected. Use these to check what the cleanup changed.
- `obituary_pairs_metadata.xlsx` has three sheets:
  - **Metadata:** one row per text, with pair ID, period, sex of the deceased, newspaper, state, date, days apart within the pair, word count, OCR'd headline, quality notes, and a link to the page scan.
  - **Summary:** live counts and mean word counts by period and sex.
  - **Column guide.**

File names encode the design. For example, `1920-07F.txt` and `1920-07M.txt` are pair 7 from the 1920s, the woman's and the man's obituary respectively.

## Source

All texts come from **Chronicling America**, the Library of Congress's digitized newspaper collection, which is public domain. They were accessed through the **American Stories** dataset (Dell et al., 2023, arXiv:2308.12477; CC BY 4.0). American Stories re-OCRs the Chronicling America scans and segments each page into individual articles, which is what makes article-level sampling possible.

Suggested citation for the underlying data: *American Stories: A Large-Scale Structured Text Dataset of Historical U.S. Newspapers* (Dell et al., 2023), derived from Chronicling America, Library of Congress.

## How the corpus was built

1. **Candidate pool.** For each sampled year, the first ~350–450 MB of the dataset's year file was streamed. This covered about 3,500–9,000 newspaper pages per year, drawn from hundreds of titles in mixed order. Articles were kept as candidates if they:
   - were marked fully legible;
   - were 100–700 words long;
   - mentioned a death in the opening lines;
   - contained at least two obituary markers ("funeral," "survived by," "interment," "cemetery," and so on);
   - referred mainly to one person, judged by pronouns.

   This is a large, varied sample of the digitized press, but not a statistically random sample of all newspapers.
2. **Hand review.** Every candidate that could be paired was read and accepted or rejected by hand. Rejected items included:
   - reports centered on a crime, accident, or suicide rather than a life;
   - resolutions of respect and memorial poems;
   - columns listing several deaths;
   - miscellaneous news that merely mentioned a death.

   The sex of the deceased was assigned by reading, not by keyword.
3. **Matching.** Within each period, a woman's and a man's obituary were paired only if they came from the same newspaper. Pairs were chosen greedily by the smallest gap between publication dates, with at most one pair per newspaper (two in the 1950s, where fewer titles are digitized).
   - Pairs from the same issue: 55 of 100.
   - 1900s, 1920s, and 1950s: every pair falls within about a month.
   - 1880s: pairs fall within a year (median gap of about six weeks), because fewer papers from that decade printed matchable obituaries.
4. **Transcription check.** Every text was verified character for character against the source record after it was assembled.

## What students should know

**The 50/50 split is a design choice.** In the keyword-filtered candidate pool, before hand review, texts about men outnumbered texts about women by roughly 1.6 to 2.5 to one, depending on the period. That count is rough, but it suggests who got an obituary at all was itself gendered. The matching controls for newspaper and date, but it does not show how often each sex appeared.

**The texts are OCR.** Expect errors such as "Mr.." for "Mr.", "i'll" for "ill", "81" for "31", "1t" for "It", and implausible dates (a birth year of "1910" in an 1887 obituary). Treat any number or date in the text with suspicion, and use the scan link to check passages that matter to an argument. The clean versions fix only a short list of frequent, unambiguous artifacts:
- rejoined hyphenated line breaks;
- "Mr..", "Mrs..", "DR.." normalized;
- "i'll" corrected to "ill";
- "we'll known" corrected to "well known";
- "we're" corrected to "were";
- "VIM." corrected to "Wm."

Nothing else was corrected. The OCR noise may affect LLM annotation, and students should say so in their methodology.

**Flags in the `notes` column:**
- *Trimmed* (10 texts): the source block also contained unrelated local news or a second obituary, which was cut. Nothing was cut from inside an obituary.
- *Truncated in source* (9 texts): the digitized article ends mid-sentence, usually because the story continued on another page.
- *Heavy OCR noise* (8 texts): still usable, but hard to read in places.
- *Short* (1 text): 1880-21M runs 67 words after trimming.

**Genre changes across periods.** 1880s obituaries are often effusive and religious, and sometimes include verse. By the 1950s they are formulaic funeral-home notices listing survivors. Comparisons across periods should keep this in mind.

**Sensitive content.** The texts use the language of their time, including racial designations such as "colored" and descriptions of slavery (for example 1920-14M, a man born enslaved in Maryland). Causes of death, including cancer, mental illness, and childbirth, are described frankly.

## Possible research angles

- What is a life anchored in: work, family, church, clubs, or character?
- Is a woman named in her own right or as "Mrs. [Husband's name]"?
- Achievement vocabulary versus virtue vocabulary.
- Length and detail of women's versus men's obituaries.
- Who is listed as survivors, and in what order?
- How do all of these change from the 1880s to the 1950s?

A simple design is to hand-code 20–30 texts and compare those codes with the LLM's scores before trusting the model on the full set.
